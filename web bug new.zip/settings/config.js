module.exports = {
  Token: "8163814073:AAGtA4L3Uz4QQQTD8ZUt8Ei0ASIgXimFfw4",
  owner: "6629230649",
};